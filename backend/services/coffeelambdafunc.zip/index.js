"use strict";
import { dynamo, PutItemCommand } from './main'
// Load the required clients and commands.
// const { ScanCommand }  = require ( "@aws-sdk/client-dynamodb" );
// const { PublishCommand } = require ( "@aws-sdk/client-sns" );
// const {snsClient} = require ( "./libs/snsClient" );

// // Get today's date.
// const today = new Date();
// const dd = String(today.getDate()).padStart(2, "0");
// const mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
// const yyyy = today.getFullYear();
// const date = yyyy + "-" + mm + "-" + dd;

// Set the parameters for the ScanCommand method.
// const params = {
//   // Specify which items in the results are returned.
//   FilterExpression: "startDate = :topic",
//   // Define the expression attribute value, which are substitutes for the values you want to compare.
//   ExpressionAttributeValues: {
//     ":topic": { S: date },
//   },
//   // Set the projection expression, which the the attributes that you want.
//   ProjectionExpression: "firstName, phone",
//   TableName: "TABLE_NAME",
// };


exports.handler = async (event, context) => {
  console.log(event)
  // event.Records.forEach(record => {
  //   const { body } = record;
  //   console.log(body);

    // const params = {
    //   TableName: "COFFEE_APP_TABLE",
    //   Item: {
    //     StoreID: { S: "n" },
    //     StoreName: { S: "n" },
    //     StoreImage: { S: "n" },
    //     StoreRating: { N: "n" },
    //     StoreComment: { S: "n" },
    //     // CUSTOMER_ID: { N: "001" },
    //     // CUSTOMER_NAME: { S: "Richard Roe" },
    //   },
    // };

  // });

    // try {
    //   // Scan the table to check identify employees with work anniversary today.
    //   const data = await dynamoClient.send(new ScanCommand(params));
    //   data.Items.forEach(function (element, index, array) {
    //     const textParams = {
    //       PhoneNumber: element.phone.N,
    //       Message:
    //         "Hi " +
    //         element.firstName.S +
    //         "; congratulations on your work anniversary!",
    //     };
    //     // Send message using Amazon SNS.
    //     sendText(textParams);
    //   });
    // } catch (err) {
    //   console.log("Error, could not scan table ", err);
    // }
};